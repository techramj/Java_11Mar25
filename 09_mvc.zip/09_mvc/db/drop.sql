drop table users;
drop table emp;
drop sequence seq_user_id;
drop sequence seq_emp_id;