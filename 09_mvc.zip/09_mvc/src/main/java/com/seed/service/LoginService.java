package com.seed.service;

import java.util.List;

import com.seed.entity.User;

public interface LoginService {
	
	public boolean isValidUser(String username,String password);
	public User getUserDetails(String username);
	public List<String> getFriends(String username);

}
