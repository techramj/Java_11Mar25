package com.seed.service.imp;

import java.sql.Connection;
import java.util.List;

import com.seed.dao.UserDao;
import com.seed.dao.impl.UserDaoImpl;
import com.seed.entity.User;
import com.seed.service.LoginService;

public class LoginServiceImpl implements LoginService {
	
	private UserDao  userDao;
	
	

	public LoginServiceImpl(Connection con) {
		this.userDao = new UserDaoImpl(con);
	}

	@Override
	public boolean isValidUser(String username, String password) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public User getUserDetails(String username) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> getFriends(String username) {
		// TODO Auto-generated method stub
		return null;
	}

}
