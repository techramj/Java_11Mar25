package com.seed.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.seed.entity.User;
import com.seed.service.LoginService;
import com.seed.service.imp.LoginServiceImpl;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

	LoginService  loginService;

	@Override
	public void init() throws ServletException {
		
		Connection con = (Connection) getServletContext().getAttribute("connection");
		loginService = new LoginServiceImpl(con);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String username = request.getParameter("username");
		String password = request.getParameter("password");
		System.out.println(username + "   " + password);

		ServletContext context = this.getServletContext();
		context.setAttribute("username", username);

		boolean isValidUser = loginService.isValidUser(username, password);
		User user = null;
	    if (isValidUser) {
			user = loginService.getUserDetails(username);
	    }
		String viewName;
		if (isValidUser) {

			HttpSession session = request.getSession();
			session.setAttribute("username", username);
			session.setAttribute("user", user);	
			viewName = "WEB-INF/views/homePage.jsp";
			
		} else {
			viewName ="index.jsp";
		}
		RequestDispatcher rd = request.getRequestDispatcher("");
		rd.forward(request, response);
		
	}

}