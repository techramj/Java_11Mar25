package com.seed.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.seed.entity.User;

public interface UserDao {
	
	public User getUserDetail(String username) throws SQLException;
	public List<User> getAllUser() throws SQLException;
	public List<String> getFriends(String username) throws SQLException;
	public List<String> getFriends(int userId) throws SQLException;
	public void addUser(User user) throws SQLException;
	public void deleteUser(int userId) throws SQLException;
	public void updateUser(User user) throws SQLException;
	public void addFriend(String username, String friendName);
	public void addFriend(int userId, String friendName);
	
    default User getUser(ResultSet rs) throws SQLException {
		User user = new User();
		user.setUserid(rs.getInt(1));
		user.setUsername(rs.getString(2));
		user.setPassword(rs.getString(3));
		user.setFirstName(rs.getString(4));
		user.setLastName(rs.getString(5));
		return user;
	}
}
