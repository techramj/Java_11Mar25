package com.seed.dao.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.seed.dao.UserDao;
import com.seed.entity.User;
import com.seed.util.ConnectionUtil;

public class UserDaoImpl implements UserDao {
	
	private Connection connection ;
	
	public UserDaoImpl(Connection connection) {
		this.connection = connection;
	}

	@Override
	public User getUserDetail(String username) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<User> getAllUser() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> getFriends(String username) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> getFriends(int userId) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addUser(User user) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteUser(int userId) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateUser(User user) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addFriend(String username, String friendName) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addFriend(int userId, String friendName) {
		// TODO Auto-generated method stub
		
	}

}
