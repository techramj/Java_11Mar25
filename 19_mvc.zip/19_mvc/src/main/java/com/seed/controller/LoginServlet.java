package com.seed.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.seed.entity.User;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		String page;
		
		if("123".equals(password)) {
			User user = new User(1,"Ram","Jaiswal","rjramjaiswal@test.com");
			req.setAttribute("user", user);
			req.setAttribute("username", username);
			page ="WEB-INF/views/home.jsp";
		}else {
			//model
			req.setAttribute("error", "Invalid Username and password");
			page="login.jsp";
		}
		
		RequestDispatcher rd = req.getRequestDispatcher(page);
		rd.forward(req, resp);
	}

}
