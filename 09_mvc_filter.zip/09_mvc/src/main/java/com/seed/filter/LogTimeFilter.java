package com.seed.filter;

import java.io.IOException;
import java.net.http.HttpRequest;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;


@WebFilter("*")
public class LogTimeFilter extends HttpFilter implements Filter {
       
    public LogTimeFilter() {
        System.out.println(this.getClass().getSimpleName()+"  object created....");
    }


	public void init(FilterConfig fConfig) throws ServletException {
		System.out.println(this.getClass().getSimpleName()+"  init called....");
	}
	
	public void destroy() {
		System.out.println(this.getClass().getSimpleName()+"  destroy called....");
	}


	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		System.out.println("before chain.doFilter");
		
		HttpServletRequest req = (HttpServletRequest)request;
		
		long t1 = System.currentTimeMillis();
		chain.doFilter(request, response);
		long t2 = System.currentTimeMillis();
		System.out.println("after chain.doFilter");
		System.out.println("Time taken for "+req.getServletPath()+" : "+(t2-t1)+" ms");
	}

	

}
