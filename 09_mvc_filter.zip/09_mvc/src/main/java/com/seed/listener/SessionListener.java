package com.seed.listener;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * Application Lifecycle Listener implementation class SessionListener
 *
 */
@WebListener
public class SessionListener implements HttpSessionListener {
	
	private static int activeUserCount;


    public void sessionCreated(HttpSessionEvent se)  { 
    	activeUserCount++;
    }


    public void sessionDestroyed(HttpSessionEvent se)  { 
    	activeUserCount--;
    }
	
    public static int getActiveUserCount() {
		return activeUserCount;
	}
}
