package com.seed.listener;

import java.sql.Connection;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.seed.util.ConnectionUtil;

@WebListener
public class MyApplicationListener implements ServletContextListener {

    public MyApplicationListener() {
       
    }
    
    @Override
    public void contextInitialized(ServletContextEvent sce) {
    	System.out.println(this.getClass().getSimpleName()+"  called.....");
    	ServletContext context = sce.getServletContext();
    	String username = context.getInitParameter("db.username");
		String password = context.getInitParameter("db.password");
		String drivername = context.getInitParameter("db.drivername");
		String url = context.getInitParameter("db.url");
		
		Connection con = ConnectionUtil.getConnection(drivername, url, username, password);
		context.setAttribute("connection", con);
    }
	
}
