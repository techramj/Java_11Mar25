create sequence seq_user_id
start with 1000;

create table users(
userid number primary key, 
username varchar2(20), 
password varchar2(20), 
first_name varchar2(20),
last_name varchar2(20)
);

insert into users(userid, username, password, first_name, last_name) 
values (seq_user_id.nextval, 'bhushanp', '123', 'Bhushan','Patil');

create sequence seq_emp_id
start with 100;

create table emp
(id number primary key,
name varchar2(20),
salary number,
email  varchar2(20)
);


insert into emp
select seq_emp_id.nextval, last_name, salary, email from employees
where employee_id<=120;

commit;
